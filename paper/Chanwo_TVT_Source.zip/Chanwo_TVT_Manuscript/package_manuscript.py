from pathlib import Path
import zipfile,json,hashlib,re
P=Path(__file__).resolve().parent
names=['main.tex','references.bib','IEEEtran.cls','IEEEtran.bst','README.txt','author_information.txt','analyze_native.py','make_native_figures.py','draw_architecture.py','palette.py','prepare_fonts.ps1','finish_build.ps1','final_audit.py','package_manuscript.py']
files=[P/n for n in names]+sorted((P/'sections').glob('*.tex'))
tex='\n'.join(f.read_text() for f in (P/'sections').glob('*.tex'))
files += [P/(n+'.tex') for n in sorted(set(re.findall(r'\\input\{(analysis/[^}]+)\}',tex)))]
files += [P/n for n in sorted(set(re.findall(r'\\includegraphics\[[^\]]+\]\{([^}]+)\}',tex)))]
files += sorted((P/'inputs/native').glob('*.json'))+[P/'inputs/native_study/results'/n for n in ['comparison100.jsonl','components100.jsonl','selection100.jsonl']]
files += [P/'inputs/connector_geometry.json',P/'build/main.bbl']
for n in ['summary.json','component_summary.json','selection_summary.json','branch_counts.json','manuscript_audit.json','repository_release.json']:
 if (P/'analysis'/n).exists():files.append(P/'analysis'/n)
files=list(dict.fromkeys(files));manifest={f.relative_to(P).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
(P/'source_manifest.json').write_text(json.dumps(manifest,indent=2));files.append(P/'source_manifest.json')
zpath=P/'Chanwo_TVT_Source.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for f in files:z.write(f,'Chanwo_TVT_Manuscript/'+f.relative_to(P).as_posix())
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for n,digest in manifest.items():assert hashlib.sha256(z.read('Chanwo_TVT_Manuscript/'+n)).hexdigest()==digest
print(json.dumps({'zip':str(zpath),'files':len(files),'megabytes':round(zpath.stat().st_size/1048576,2)},indent=2))
