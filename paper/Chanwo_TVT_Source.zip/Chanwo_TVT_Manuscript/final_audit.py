from pathlib import Path
from pypdf import PdfReader
import json,hashlib,re
P=Path(__file__).resolve().parent
path=P/'Chanwo_TVT_Manuscript.pdf'
pdf=PdfReader(path);log=(P/'build/main.log').read_text(errors='replace')
bbl=(P/'build/main.bbl').read_text(errors='replace')
tex='\n'.join(f.read_text(encoding='utf-8') for f in (P/'sections').glob('*.tex'))
inputs=re.findall(r'\\input\{(analysis/[^}]+)\}',tex)
tex+='\n'+'\n'.join((P/(f+'.tex')).read_text(encoding='utf-8') for f in inputs)
intro=(P/'sections/01_introduction.tex').read_text(encoding='utf-8')
intro=re.sub(r'\\(?:cite|section|ref)\{[^}]+\}','',intro)
first=re.sub(r'\s+','',pdf.pages[0].extract_text())
names=['Bai Li','Fan Bu','Guizhen Yu','Zhijiang Shao']
positions=[first.index(n.replace(' ','')) for n in names];assert positions==sorted(positions)
for email in ['libai@zju.edu.cn','fanbu@buaa.edu.cn','yugz@buaa.edu.cn','szj@zju.edu.cn']:assert email in first
ids=['0000-0002-8966-8992','0009-0000-2581-6776','0000-0001-8374-7422','0000-0003-3016-4658']
links=[str(a.get_object().get('/A',{}).get('/URI','')) for a in pdf.pages[0].get('/Annots',[])]
assert all('https://orcid.org/'+x in links for x in ids)
graphics=re.findall(r'\\includegraphics\[[^\]]+\]\{([^}]+)\}',tex)
figs=[f for f in graphics if f.startswith('figures/')]
portraits=[f for f in graphics if f.startswith('portraits/')]
assert len(portraits)==4
from PIL import Image
for f in portraits:
 im=Image.open(P/f);assert im.mode=='L' and im.width>=300 and im.height>=375
assert tex.count(r'\begin{IEEEbiography}')==4
assert len(figs)==9 and all((P/f).exists() for f in figs)
alltext='\n'.join(pg.extract_text() for pg in pdf.pages)
assert not re.search(r'\bB\d{3}\b',tex)
assert 'Fig. 1.' in pdf.pages[0].extract_text()
assert 'github.com/libai1943/' in re.sub(r'\s+','',alltext)
assert 'Extended First-Solution Diagnostics' not in alltext
assert 'Continuous Coverage and Hybrid A*' not in alltext
assert r'\label{fig:diagnostics}' not in tex
abstract_text=re.search(r'\\begin\{abstract\}(.*?)\\end\{abstract\}',(P/'main.tex').read_text(),re.S).group(1)
assert not re.search(r'\d',abstract_text)
assert 'on 51 of the 100 tasks, including ties' in (P/'sections/09_conclusion.tex').read_text()
assert 'Best counts are computed over all 100 tasks among the successful methods, including ties.' in tex
font_check={}
for f in figs:
 if not f.endswith('.pdf'):continue
 fonts=set()
 for pg in PdfReader(P/f).pages:
  for v in pg['/Resources'].get('/Font',{}).values():fonts.add(str(v.get_object().get('/BaseFont')))
 assert fonts and all('TimesNewRoman' in x for x in fonts),(f,fonts)
 font_check[f]=sorted(fonts)
caption_counts=[]
for source in (P/'sections').glob('*.tex'):
 for block in re.findall(r'\\begin\{figure\*?\}(.*?)\\end\{figure\*?\}',source.read_text(),re.S):
  cap=re.search(r'\\caption\{([^}]+)\}',block).group(1)
  words=len(re.findall(r"\b[\w]+(?:[-'][\w]+)*\b",cap));limit=15 if source.name=='00_scene.tex' else 20
  if r'\label{fig:ablation}' in block:
   assert cap.endswith('All means use the 100 benchmark tasks; planning times are measured in the candidate-selection study.')
   limit=32
  assert words<=limit,(source,cap,words)
  caption_counts.append({'file':source.name,'words':words})
result=json.loads((P/'analysis/summary.json').read_text())
assert result['methods']['BRS']['success']==100
pages=[i+1 for i,pg in enumerate(pdf.pages) if 'TABLE I\n' in pg.extract_text()]
assert pages==[3],pages
checks={'pages':len(pdf.pages),'authors':names,'orcid':dict(zip(names,ids)),
 'intro_words':len(re.findall(r"\b[\w]+(?:[-'][\w]+)*\b",intro)),
 'references':len(re.findall(r'\\bibitem\{',bbl)),'figures':len(figs),
 'candidate_caption_scope_exception':True,
 'author_portraits':portraits,
 'tables':len(re.findall(r'\\begin\{table\*?\}',tex)),
 'table_I_page':pages[0],'caption_counts':caption_counts,
 'overfull_diagnostics':len(re.findall('Overfull',log)),
 'undefined_reference_diagnostics':len(re.findall(r'(?:Reference|Citation).*undefined|undefined references',log,re.I)),
 'figure_font_resources':font_check,'BRS_successes':100,
 'pdf_bytes':path.stat().st_size,'pdf_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
assert checks['pages']<=15 and checks['intro_words']<400
assert checks['overfull_diagnostics']==0 and checks['undefined_reference_diagnostics']==0
(P/'analysis/manuscript_audit.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in checks.items() if k!='figure_font_resources'},ensure_ascii=False,indent=2))
