param([string]$Python='python',[string]$Tectonic='tectonic',[string]$FontDir='C:\Windows\Fonts')
$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 & $Python -B -X utf8 analyze_native.py
 if ($LASTEXITCODE -ne 0) { throw 'Analysis failed' }
 & $Python -B -X utf8 draw_architecture.py --font-dir $FontDir
 if ($LASTEXITCODE -ne 0) { throw 'Architecture figure failed' }
 & $Python -B -X utf8 make_native_figures.py
 if ($LASTEXITCODE -ne 0) { throw 'Numerical figures failed' }
 & $Tectonic --keep-logs --keep-intermediates --outdir build main.tex
 if ($LASTEXITCODE -ne 0) { throw 'TeX compilation failed' }
 Copy-Item -LiteralPath build/main.pdf -Destination Chanwo_TVT_Manuscript.pdf -Force
 & $Python -B -X utf8 final_audit.py
 if ($LASTEXITCODE -ne 0) { throw 'Manuscript audit failed' }
 & $Python -B -X utf8 package_manuscript.py
 if ($LASTEXITCODE -ne 0) { throw 'Source packaging failed' }
} finally { Pop-Location }
