$ErrorActionPreference = 'Stop'
$taskFontDir = Join-Path $PSScriptRoot 'fonts'
New-Item -ItemType Directory -Path $taskFontDir -Force | Out-Null
foreach ($taskFontName in @('times.ttf', 'timesbd.ttf', 'timesi.ttf', 'timesbi.ttf')) {
    $taskFontSource = Join-Path (Join-Path $env:WINDIR 'Fonts') $taskFontName
    if (-not (Test-Path -LiteralPath $taskFontSource)) { throw "Times New Roman is not installed: $taskFontSource" }
    Copy-Item -LiteralPath $taskFontSource -Destination (Join-Path $taskFontDir $taskFontName) -Force
}
Write-Output 'Local Times New Roman font faces prepared. Compile main.tex with Tectonic or XeLaTeX.'
