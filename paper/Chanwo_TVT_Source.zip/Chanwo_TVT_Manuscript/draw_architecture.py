#!/usr/bin/env python3
"""Figure 2: compact BRS flowchart with genuine Times New Roman.

Technical content follows the native BRS shared-deadline solver.
Flat branch panels; prioritized calls; bounded selection and prefix continuation.

Creates editable SVG, embedded-font vector PDF, grayscale versions, and PNG.
Install dependencies: python -m pip install reportlab pymupdf pillow
Run: python draw_architecture.py --font-dir /path/to/times-fonts
The font folder must contain TIMES.TTF, TIMESBD.TTF, TIMESI.TTF, TIMESBI.TTF.
The original font files are not redistributed with this figure.
"""
from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from html import escape
from pathlib import Path

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor


W, H = 1600, 700
WIDTH_MM = 178
SCALE = WIDTH_MM / 25.4 * 72 / W
OUT = Path(__file__).resolve().parent / 'figures'
FONT_NAMES = {"regular": "TNR", "bold": "TNR-Bold", "italic": "TNR-Italic", "bolditalic": "TNR-BoldItalic"}
FONT_FILES = {"regular": "TIMES.TTF", "bold": "TIMESBD.TTF", "italic": "TIMESI.TTF", "bolditalic": "TIMESBI.TTF"}

COLOR = {
    "ink": "#171717", "line": "#252525", "white": "#FFFFFF",
    "gray": "#F3F3F3", "blue": "#A9D3E6", "blue_light": "#EDF5F9",
    "green": "#C7DEC1", "amber": "#F1D38D", "label": "#365A8D",
}
GRAY = {
    "ink": "#171717", "line": "#252525", "white": "#FFFFFF",
    "gray": "#F3F3F3", "blue": "#D7D7D7", "blue_light": "#F5F5F5",
    "green": "#E1E1E1", "amber": "#D7D7D7", "label": "#333333",
}


@dataclass
class Run:
    text: str
    font: str = "regular"
    size: float = 26
    dy: float = 0


class Figure:
    def __init__(self, palette):
        self.p = palette
        self.items = []
        self.text_extents = []

    def rect(self, x, y, w, h, fill="white", stroke="line", sw=1.8):
        self.items.append(("rect", dict(x=x, y=y, w=w, h=h, fill=fill, stroke=stroke, sw=sw)))

    def line(self, points, arrow=False, width=2.1, color="line"):
        for a, b in zip(points, points[1:]):
            if a[0] != b[0] and a[1] != b[1]:
                raise ValueError("All flow connectors must be orthogonal")
        self.items.append(("line", dict(points=points, arrow=arrow, width=width, color=color)))

    def text(self, x, y, text, size=26, font="regular", anchor="middle", color="ink", max_width=None):
        return self.rich(x, y, [Run(text, font, size)], anchor, color, max_width)

    def rich(self, x, y, runs, anchor="middle", color="ink", max_width=None):
        width = sum(pdfmetrics.stringWidth(r.text, FONT_NAMES[r.font], r.size) for r in runs)
        if max_width is not None and width > max_width + 0.01:
            raise ValueError(f"Text too wide ({width:.1f} > {max_width}): {''.join(r.text for r in runs)}")
        left = x - width / 2 if anchor == "middle" else x - width if anchor == "end" else x
        self.text_extents.append({"text": "".join(r.text for r in runs), "x0": left, "x1": left+width, "baseline": y, "size": max(r.size for r in runs)})
        cursor = left
        for r in runs:
            self.items.append(("text", dict(x=cursor, y=y+r.dy, text=r.text, font=r.font, size=r.size, color=color)))
            cursor += pdfmetrics.stringWidth(r.text, FONT_NAMES[r.font], r.size)

    def process(self, x, y, w, h, lines, size=26):
        self.rect(x, y, w, h, "gray", sw=1.5)
        if len(lines) == 1:
            self.text(x+w/2, y+h/2+size*0.31, lines[0], size, max_width=w-16)
        else:
            gap = size * 1.03
            start = y+h/2 - (len(lines)-1)*gap/2 + size*0.31
            for i, text in enumerate(lines):
                self.text(x+w/2, start+i*gap, text, size, max_width=w-16)

    def panel(self, x, y, w, h, title, color, title_size=28, header_height=42):
        self.rect(x, y, w, h, "white")
        self.rect(x, y, w, header_height, color)
        self.text(x+w/2, y+header_height/2+title_size*0.31, title, title_size, "bold", max_width=w-20)

    def arrow_triangle(self, points):
        x2, y2 = points[-1]
        x1, y1 = points[-2]
        dx, dy = x2-x1, y2-y1
        d = math.hypot(dx, dy)
        dx, dy = dx/d, dy/d
        size, half = 9.4, 4.25
        return [(x2,y2), (x2-size*dx-half*dy,y2-size*dy+half*dx), (x2-size*dx+half*dy,y2-size*dy-half*dx)]

    def svg(self):
        out = [f'<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH_MM}mm" height="{WIDTH_MM*H/W:.6f}mm" viewBox="0 0 {W} {H}" role="img" aria-labelledby="title desc">',
               '<title id="title">BRS planning framework</title>',
               '<desc id="desc">Compact rectangular BRS flowchart. Branch I returns its first complete feasible reverse-only trajectory. Heading difference prioritizes the one-cusp branches. Only the successful construction performs bounded J-based candidate selection. Failed constructions advance the branch or sampling level; exhausted local attempts invoke breadth-first prefix continuation under the same deadline. Every label uses Times New Roman.</desc>']
        for kind, a in self.items:
            if kind == "rect":
                out.append(f'<rect x="{a["x"]}" y="{a["y"]}" width="{a["w"]}" height="{a["h"]}" fill="{self.p[a["fill"]]}" stroke="{self.p[a["stroke"]] if a["stroke"] else "none"}" stroke-width="{a["sw"]}"/>')
            elif kind == "line":
                points = ' '.join(f'{x},{y}' for x,y in a['points'])
                out.append(f'<polyline points="{points}" fill="none" stroke="{self.p[a["color"]]}" stroke-width="{a["width"]}" stroke-linecap="butt" stroke-linejoin="miter"/>')
                if a['arrow']:
                    tri=' '.join(f'{x:.4f},{y:.4f}' for x,y in self.arrow_triangle(a['points']))
                    out.append(f'<polygon points="{tri}" fill="{self.p[a["color"]]}"/>')
            elif kind == "text":
                weight = '700' if 'bold' in a['font'] else '400'
                style = 'italic' if 'italic' in a['font'] else 'normal'
                out.append(f'<text x="{a["x"]:.5f}" y="{a["y"]:.5f}" fill="{self.p[a["color"]]}" font-family="Times New Roman" font-size="{a["size"]}" font-weight="{weight}" font-style="{style}" xml:space="preserve">{escape(a["text"])}</text>')
        return '\n'.join(out+['</svg>'])

    def pdf(self, path):
        c = canvas.Canvas(str(path), pagesize=(W*SCALE,H*SCALE), pageCompression=1, initialFontName=FONT_NAMES['regular'], initialFontSize=26*SCALE)
        c.setTitle('Figure 2 - BRS planning framework')
        c.setAuthor('')
        c.setSubject('BRS framework; Times New Roman embedded')
        c.scale(SCALE, SCALE)
        c.setLineJoin(0)
        c.setLineCap(0)
        for kind, a in self.items:
            if kind == "rect":
                c.setFillColor(HexColor(self.p[a['fill']]))
                if a['stroke']:
                    c.setStrokeColor(HexColor(self.p[a['stroke']]))
                c.setLineWidth(a['sw'])
                c.rect(a['x'], H-a['y']-a['h'], a['w'], a['h'], stroke=bool(a['stroke']), fill=True)
            elif kind == "line":
                c.setStrokeColor(HexColor(self.p[a['color']]))
                c.setLineWidth(a['width'])
                p = c.beginPath()
                p.moveTo(a['points'][0][0], H-a['points'][0][1])
                for x,y in a['points'][1:]:
                    p.lineTo(x,H-y)
                c.drawPath(p)
                if a['arrow']:
                    tri = self.arrow_triangle(a['points'])
                    p = c.beginPath()
                    p.moveTo(tri[0][0],H-tri[0][1])
                    for x,y in tri[1:]: p.lineTo(x,H-y)
                    p.close()
                    c.setFillColor(HexColor(self.p[a['color']]))
                    c.drawPath(p, stroke=False, fill=True)
            elif kind == "text":
                c.setFillColor(HexColor(self.p[a['color']]))
                c.setFont(FONT_NAMES[a['font']], a['size'])
                c.drawString(a['x'], H-a['y'], a['text'])
        c.showPage()
        c.save()


def index(symbol, suffix, size=26):
    return [Run(symbol,'italic',size), Run(suffix,'regular',size*0.68,size*0.20)]


def build(palette):
    f = Figure(palette)
    f.rect(0,0,W,H,'white',None,0)

    # Prefix continuation creates a new local invocation with its full prefix.
    f.line([(90,577),(36,577),(36,42),(90,42)],arrow=True)

    # The scheduler invokes one II/III construction at a time in the stated order.
    f.line([(1540,560),(1568,560),(1568,112),(800,112)])
    f.line([(390,66),(390,91)])
    f.line([(390,91),(310,91),(310,132)],arrow=True)
    f.line([(800,112),(1290,112)])
    for cx in [800,1290]:
        f.line([(cx,112),(cx,132)],arrow=True)

    f.rect(90,18,600,48,'gray')
    f.text(390,50,'Current start | Goal/map | Retained prefix',28,max_width=575)
    f.rich(1120,48,[
        Run('II/III order:  II → III (',size=28),Run('Δ','italic',28),
        Run(' ≤ ',size=28),Run('α','italic',28),Run(');  III → II (',size=28),
        Run('Δ','italic',28),Run(' > ',size=28),Run('α','italic',28),Run(')',size=28),
    ],max_width=800)

    # One flat panel per family; no nested process boxes or step arrows.
    branches = [
        (90,'I. Reverse-only','Direct closure; then layered search','0 local cusps'),
        (580,'II. Goal-side','Direct entry; then reverse-entry fans','≤1 local cusp'),
        (1070,'III. Start-side','Forward-departure fans','≤1 local cusp'),
    ]
    for x,title,line,foot in branches:
        f.panel(x,132,440,147,title,'green',31,40)
        f.text(x+220,205,line,25.5,max_width=416)
        if x == 90:
            f.text(x+220,235,'Return first feasible trajectory',27,max_width=416)
        elif x == 580:
            f.text(x+220,235,'Forward connection to cusp',27,max_width=416)
        else:
            f.text(x+220,235,'Reverse connection to goal',27,max_width=416)
        f.text(x+220,265,foot,26,'italic',max_width=416)

    f.line([(310,279),(310,309),(1290,309),(1290,279)])
    f.line([(800,279),(800,342)],arrow=True)
    f.rich(830,333,[Run('II/III: at most ',size=25.5)]+index('K','f',25.5)+[Run(' feasible candidates; at most ',size=25.5)]+index('τ','sel',25.5)+[Run(' after first solution',size=25.5),],anchor='start',color='label',max_width=700)

    # All candidates share validation and timing; II/III select within the successful construction.
    f.rect(530,342,545,94,'blue_light')
    f.text(802.5,378,'Validate and time-parameterize',29,'bold',max_width=517)
    f.rich(802.5,415,[Run('II/III: min ',size=28),Run('J','italic',28),Run(' = ',size=28)]+index('T','f',28)+[Run(' + ',size=28)]+index('λ','s',28)+[Run(' ',size=28)]+index('N','s',28),max_width=517)

    f.line([(1075,394),(1190,394)],arrow=True)
    f.text(1132.5,377,'Feasible',26,color='label')
    f.rect(1190,342,350,105,'gray')
    f.text(1365,376,'Return trajectory',30,'bold',max_width=326)
    f.text(1365,406,'From the original start',25.5,max_width=330)
    f.text(1365,435,'Keep the validated incumbent',25.5,max_width=330)

    # A construction without a complete feasible trajectory advances the branch or level.
    f.line([(800,436),(800,487),(1365,487),(1365,520)],arrow=True)
    f.text(1082,474,'No complete feasible trajectory',25.5,color='label',max_width=425)
    f.rect(1190,520,350,80,'gray')
    f.text(1365,551,'Next branch / level',30,'bold',max_width=326)
    f.text(1365,583,'Within the shared deadline',27,max_width=326)

    f.line([(1190,577),(740,577)],arrow=True)
    f.text(962,560,'All local attempts failed',26,color='label',max_width=425)
    f.panel(90,520,650,105,'Breadth-first prefix continuation','amber',30,40)
    f.text(415,587,'Gear × steering × length',27,max_width=620)
    f.text(415,615,'Validated child → new start; retain prefix',27,max_width=620)

    f.line([(740,611),(790,611),(790,657),(840,657)],arrow=True)
    f.text(1005,617,'Queue / budget exhausted',25.5,color='label',max_width=400)
    f.rect(840,631,330,52,'gray')
    f.text(1005,666,'No solution within budget',27,'bold',max_width=310)
    f.rich(415,668,[Run('Shared deadline ',size=25.5)]+index('τ','max',25.5)+[Run(' for every operation',size=25.5)],max_width=650)
    return f


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--font-dir', type=Path, required=True)
    parser.add_argument('--no-png',action='store_true')
    args = parser.parse_args()
    for style,filename in FONT_FILES.items():
        source=args.font_dir/filename
        if not source.is_file():
            raise FileNotFoundError(f'Required genuine Times New Roman font is missing: {source}')
        pdfmetrics.registerFont(TTFont(FONT_NAMES[style],str(source)))
    for name,palette in [('architecture',COLOR),('architecture_grayscale',GRAY)]:
        figure=build(palette)
        (OUT/(name+'.svg')).write_text(figure.svg(),encoding='utf-8')
        figure.pdf(OUT/(name+'.pdf'))
        if palette is COLOR:
            (OUT/'layout_check.json').write_text(json.dumps(figure.text_extents,indent=2),encoding='utf-8')
    if not args.no_png:
        import pymupdf as fitz
        from PIL import Image
        pdf=fitz.open(OUT/'architecture.pdf')
        page=pdf[0]
        for dpi, suffix in [(600,''),(220,'_Preview')]:
            pix=page.get_pixmap(dpi=dpi,alpha=False)
            Image.frombytes('RGB',(pix.width,pix.height),pix.samples).save(
                OUT/('architecture'+suffix+'.png'), dpi=(dpi,dpi))
        pdf.close()
    print(f'Created vector figure: {WIDTH_MM} x {WIDTH_MM*H/W:.2f} mm; Times New Roman embedded.')


if __name__ == '__main__':
    main()
